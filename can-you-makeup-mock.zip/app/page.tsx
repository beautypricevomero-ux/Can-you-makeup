"use client";
import { useEffect, useState } from "react";

type Tier = { id: string; label: string; fee: number; secs: number };

export default function Home() {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("/api/settings").then(r=>r.json()).then(s=>{ setTiers(s.tiers); setLoading(false); });
  }, []);
  if (loading) return <p>Caricamento…</p>;
  return (
    <section className="space-y-6">
      <h1 className="text-3xl font-semibold">Can You Makeup</h1>
      <p>Entra nel gioco, paga il <b>Game Pass</b> e inizia a fare swipe come su Tinder: a sinistra escludi, a destra metti nel carrello. Hai tempo limitato ⏳</p>
      <div id="pass" className="grid sm:grid-cols-2 gap-4">
        {tiers.map(t => (
          <div key={t.id} className="border rounded p-4">
            <h3 className="font-medium">{t.label} — {t.fee}€</h3>
            <p className="text-sm opacity-70">Tempo: {t.secs} secondi</p>
            <button className="btn mt-3" onClick={() => window.location.href=`/play?tier=${t.id}`}>
              Acquista Pass & Gioca
            </button>
          </div>
        ))}
      </div>
      <p className="text-sm opacity-70">Pagamento via Shopify Checkout (PayPal + carte tramite Shopify Payments).</p>
    </section>
  );
}

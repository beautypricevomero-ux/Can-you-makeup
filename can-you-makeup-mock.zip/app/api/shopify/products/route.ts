import { NextResponse } from "next/server";

const MOCK = [
  { id: "p1", sector: "eyes", title: "Megavolume Mascara", description: "Volume estremo", images:[{url:"https://picsum.photos/seed/eyes1/800/600"}], variants:[{id:"gid://shopify/ProductVariant/1", price:{amount:"18.00", currencyCode:"EUR"}}]},
  { id: "p2", sector: "lips", title: "Matita Labbra", description: "Definizione perfetta", images:[{url:"https://picsum.photos/seed/lips1/800/600"}], variants:[{id:"gid://shopify/ProductVariant/2", price:{amount:"13.00", currencyCode:"EUR"}}]},
  { id: "p3", sector: "skin", title: "Primer Matte", description: "Base opacizzante", images:[{url:"https://picsum.photos/seed/skin1/800/600"}], variants:[{id:"gid://shopify/ProductVariant/3", price:{amount:"22.00", currencyCode:"EUR"}}]},
  { id: "p4", sector: "lips", title: "Tinta Labbra", description: "Colore a lunga durata", images:[{url:"https://picsum.photos/seed/lips2/800/600"}], variants:[{id:"gid://shopify/ProductVariant/4", price:{amount:"18.00", currencyCode:"EUR"}}]},
  { id: "p5", sector: "skin", title: "Correttore", description: "Alta coprenza", images:[{url:"https://picsum.photos/seed/skin2/800/600"}], variants:[{id:"gid://shopify/ProductVariant/5", price:{amount:"20.00", currencyCode:"EUR"}}]}
];

export async function POST(req: Request) {
  const { sectors } = await req.json();
  const ids = new Set(sectors.flatMap((s: any) => [s.id]));
  const products = MOCK.filter(p => ids.has(p.sector));
  return NextResponse.json({ products });
}

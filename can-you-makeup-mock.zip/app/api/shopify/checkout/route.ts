import { NextResponse } from "next/server";
export async function POST() {
  return NextResponse.json({ webUrl: "https://example.com/checkout-demo" });
}

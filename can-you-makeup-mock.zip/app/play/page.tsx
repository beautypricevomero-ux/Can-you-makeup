"use client";
import { useEffect, useMemo, useState } from "react";
import TimerBar from "@/components/TimerBar";
import SwipeCard from "@/components/SwipeCard";
import Guard from "@/components/Guard";
import { drawSectorId } from "@/lib/weighted";

type Settings = {
  tiers: { id:string; label:string; fee:number; secs:number }[];
  sectorsByTier: Record<string, { id:string; label:string; weight:number; handles:string[] }[]>;
};

export default function PlayPage({ searchParams }:{ searchParams: { tier?: string }}) {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [pool, setPool] = useState<any[]>([]);
  const [picked, setPicked] = useState<string[]>([]);
  const [keep, setKeep] = useState<any[]>([]);
  const [time, setTime] = useState(90);
  const tier = searchParams.tier || "t30";

  useEffect(()=> {
    (async () => {
      const s: Settings = await fetch("/api/settings").then(r=>r.json());
      setSettings(s);
      const sectors = s.sectorsByTier[tier];
      const res = await fetch("/api/shopify/products", { method:"POST", body: JSON.stringify({ sectors }), headers:{ "Content-Type":"application/json" }});
      const { products } = await res.json();
      setTime(s.tiers.find(t=>t.id===tier)?.secs ?? 90);
      setPool(products);
    })();
  }, [tier]);

  const current = useMemo(()=>{
    if (!settings || pool.length===0) return null;
    const sectors = settings.sectorsByTier[tier];
    for (let i=0; i<100; i++){
      const sid = drawSectorId(sectors);
      const candidates = pool.filter(p => p.sector===sid && !picked.includes(p.id));
      if (candidates.length) {
        const p = candidates[Math.floor(Math.random()*candidates.length)];
        return p;
      }
    }
    const rest = pool.filter(p=>!picked.includes(p.id));
    return rest[0] || null;
  }, [settings, pool, picked, tier]);

  function swipeLeft() { if (current) setPicked(prev=>[...prev, current.id]); }
  function swipeRight() { if (current) { setKeep(k=>[...k, current]); setPicked(prev=>[...prev, current.id]); } }

  async function onEnd() {
    if (!keep.length) { alert("Tempo scaduto! Nessun prodotto selezionato."); return; }
    const variantIds = keep.map(k => k.variants?.[0]?.id).filter(Boolean);
    const payload = { variantIds, discountCode: process.env.NEXT_PUBLIC_DEFAULT_DISCOUNT_CODE };
    const res = await fetch("/api/shopify/checkout", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) });
    const { webUrl } = await res.json();
    window.location.href = webUrl;
  }

  if (!settings) return <p>Caricamento impostazioni…</p>;

  return (
    <Guard>
      <section className="space-y-6">
        <h1 className="text-2xl font-semibold">Gioca — Tier {tier}</h1>
        <TimerBar total={time} onEnd={onEnd} />
        {current ? (
          <div className="space-y-4">
            <SwipeCard product={current} onLeft={swipeLeft} onRight={swipeRight} />
            <div className="flex gap-3 justify-center">
              <button className="btn" onClick={swipeLeft}>Non mi piace</button>
              <button className="btn" onClick={swipeRight}>Aggiungi al carrello</button>
            </div>
            <p className="text-sm opacity-70">Selezionati: {keep.length}</p>
          </div>
        ) : (
          <div>
            <p>Hai visto tutti i prodotti disponibili per questo tier.</p>
            <button className="btn" onClick={onEnd}>Vai al checkout</button>
          </div>
        )}
      </section>
    </Guard>
  );
}
